import { Component, OnInit } from '@angular/core';
import { SharedService } from "./../shared.service";

@Component({
  selector: 'app-category',
  templateUrl: './Category.component.html',
  styles: [] ,
  providers:[SharedService]
})
export class CategoryComponent implements OnInit {
 
  addWorkoutCbpm: number=0 ;
  addWorkoutTitle: string = "";
  addWorkoutNote: string = "";
  addWorkoutCategory: string = "";
  
  constructor(private _sharedService: SharedService) {} 
  

  ngOnInit() {
    this._sharedService.GetCategory();
  }
  editCategoryFunc() {  
    this._sharedService.EditCategory(this);
      
   }
   deleteCategoryFunc() {  
    this._sharedService.DeleteCategory(this);
      
   }
  
}